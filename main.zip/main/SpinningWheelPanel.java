package main;

public class SpinningWheelPanel {

}
