package main;

public interface Language {

    public String gettitleChineseAnimal();
    public String getdisclaimerChineseAnimal();
    public String getdescriptionChineseAnimal();

    public String getreadABoutZodiacs();
    public String getfindYourZodiac();
    public String gettoGoToGame();
    public String getgoBack();
}