// package main;

// import javax.swing.*;

// public class Rooster extends AnimalMain {

//     public Rooster() {
//         super("Scientific name: Gallus gallus domesticus", "Lifespan: 5 years", "Habitat: Roosters can be found in a variety of habitats, including farms, suburban chicken coops, forests, grasslands, and even deserts. They are adaptable creatures and can thrive in diverse environments, from the highlands of Scotland to the tropical regions of Asia and Africa. Roosters prefer to make their nests in secluded areas, such as under bushes or in tall grass.", "One interesting thing about: Roosters have a bad sense of smell and taste, but have good hearing.", "How many roosters are there in the world? 34.4 billion", "The story of the rooster: The rooster always sought to prevail over others. When the Jade Emperor chose the animals to participate in the race, the rooster was not on the list because it was not helpful to humans. The horse told the rooster that it could use its golden voice to wake up humans. When the rooster did, the humans were very grateful, and the Jade Emperor added the rooster to the list. On the day of the race, the rooster and dog came to the race together. During the race, the dog was not able to catch up and placed right after the rooster. Today, the dog is still angry with the rooster. In Chinese culture, the concept of “the dog chasing after the rooster” is still visible today. For example, many Chinese dogs like to chase roosters.", "Years: 1921, 1933, 1945, 1957, 1969, 1981, 1993, 2005, 2017, 2029", "What does this say about you? Roosters are confident, sociable, intelligent and optimistic", "What does it say about your success? Many Roosters have sharp views on hot issues and are good at materializing ideas. Plus their eloquence and great zeal for power, they are very suitable to be a politician, diplomat, or public speaker. For those with less political consciousness, they may consider being a tour guide or an actor/actress, because they barely feel shy when speaking or performing in public. In addition, some people born in the year of the Rooster have a discerning eye for the arts. After taking their interest in appearance into account, they will be in their elements as a fashion designer.", "Your compatibility with the other animals:", "Rooster & ox: Both animals like to think about long-term goals. They also have materialistic goals that they like to work towards because they are both hard-working zodiac animals. \nRooster & snake: Snake and rooster compatibility is defined by common goals and dedication. They both have opposite personalities, but the horoscope predicts a favorable relationship ship because of mutual diligence.", "Famous people who is this zodiac: Sophie Scholl, Tom Selleck, Kelly McGillis, Jennifer Aniston, Britney Spears, Justin Timberlake, and Taylor Momsen", "picture/longRooster.jpg", "picture/squareRooster.jpg");
//         JFrame frame = new JFrame("Rooster");
//         super.create(frame, panel);
    
//         description(frame, panel);
//         description2(frame, panel);
//         description3(frame, panel);
//     }

//     public static void main(String[] args) {
//         new Rooster();
//     }
// }
